<html>
<head>
	<title>AGREGAR</title>
</head>
<body>
	<div id="list">
		<div class="container">
					<h1>AGREGAR ELEMENTO A LA LISTA</h1>
					<form v-on:submit.prevent="addNombre">
							<input type="text" v-model="nombre">
								<input type="submit" class="btnAgregar" value="agregar">
					</form>
					<ul class="lista">
						<li class="lista" v-for="item in lista" v-text="item"></li>
					</ul>
			</div>
		</div>

	<script src="vue.js"></script>
	<script type="text/javascript">
		new Vue({
			el: '#list',
			data: {
				lista: ['JEAN', 'PIERRE', 'DEL', 'CASTILLO'],
				nombre: '',
			},
			methods: {
				addNombre: function (){
					this.lista.push(this.nombre);
					this.nombre = '';
				}
			}
		});
	</script>
</body>
</html>
