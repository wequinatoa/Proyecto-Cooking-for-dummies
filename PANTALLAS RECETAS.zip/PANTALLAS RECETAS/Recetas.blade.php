<html>
<head>
<body>
<div class="container">
    <li class="list-group">
        @foreach($listaRecetas as $receta)
            <ol class="list-group-item">
                {{$receta->nombre}}<br>
                {{$receta->modalidad}}<br>
                {{$receta->costo}}<br>
                ---------------------------
            </ol>
        @endforeach

    </li>
</div>
</body>
</head>
</html>