<!doctype html>
<htmlm lang="es">
    <head>
        <title>Ejemplo de Vueee</title>
        <meta charset="UTF-8">
        <meta name="title" content="CONCINANDO EN PAREJAS">
        <meta name="description" content="COCINAR PARA OLVIDAR LA DISTANCIA">
        <link href="http://dominio.com/hoja-de-estilos.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    <div >
        <h1> funciona ......</h1>
        <example-component></example-component>
    </div>
    </body>
</htmlm>