<html>
<head>
<body>
<div class="container">
    <li class="list-group">
        @foreach($listaRecetas as $receta)
            <ol class="list-group-item">
                {{$parejas->nombres}}<br>
                {{$parejas->modalidad}}<br>
                {{$parejas->tiempo}}<br>
                ---------------------------
            </ol>
        @endforeach

    </li>
</div>
</body>
</head>
</html>