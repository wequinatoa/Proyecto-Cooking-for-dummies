<!DOCTYPE html>
<html>

  
<head><title>Platos tipicos</title></head>
<body>
  {{--
  @for ($i=0; $i<count($listado); $i++)
    <p>{{ $listado[$i] }}</p>
  @endfor
  --}}

  @foreach ($listado as $elemento)
  <p>{{ $elemento['nombre'] }} - {{$elemento['op']}}</p>
  @endforeach

</body>
</html>