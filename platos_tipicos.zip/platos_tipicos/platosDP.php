<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class estudiantesDP extends Controller
{

  

    //
  function elegir ($plato)
    {
      switch($plato)
      {
        /*case 1: $listado = array("Colada morada","Fanesca","Pavo navideño");*/
        case 1: $listado = array(
                              array("nombre"=>"Colada morada","op"=>1),
                              array("nombre"=>"Fanesca","op"=>2),
                              array("nombre"=>"Pavo navideño","po"=>3),
                              );
        
        default: $listado = array();
        break;
      }
      return view ('lista',['listado'=> $listado]);
    }
}
